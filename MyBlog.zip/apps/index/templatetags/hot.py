from django import template
from article.models import Banner, HotArticle, Tag
register = template.Library()



@register.inclusion_tag('tag_templates/hot.html')
def hot():
    # 需要轮播图.筛选没有删除的,一次性查询出来,再排序，最后在给范围
    banners = Banner.objects.filter(is_delete=False).select_related('article').order_by('priority')[:4]

    # 需要热门文章
    hot_articles = HotArticle.objects.filter(is_delete=False).select_related('article').order_by('priority')[:3]

    # 需要tags
    tags = Tag.objects.filter(is_delete=False)[:5]

    return {"banners":banners, "hot_articles":hot_articles, "tags":tags}


@register.inclusion_tag('tag_templates/side_hot.html')
def side_hot():
    # 需要热门文章
    hot_article = HotArticle.objects.filter(is_delete=False).select_related('article').order_by('priority')[0]
    return {"hot_article":hot_article}
