import logging

from django.shortcuts import render
from django.views.generic import ListView
from article.models import Article


# Create your views here.
log = logging.getLogger('hkblog')

class ArticleView(ListView):
    template_name = 'index/index.html'
    paginate_by = 2

    def get_queryset(self):
        tag_id = int(self.request.GET.get('tag', 0))
        try:
            queryset = Article.objects.all()
            log.info('文章第一条数据是{}'.format(queryset.filter()))
        except Exception as e:
            log.error(e)

        if tag_id:
            queryset = queryset.filter(tag_id=tag_id)
        return queryset

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data()
        tag_id = int(self.request.GET.get('tag', 0))
        context['tag_id'] = tag_id
        return context     
