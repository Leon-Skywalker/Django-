from django.db import models
from utills.basemodel import BaseModel

# Create your models here.


class Doc(BaseModel):
    img_url = models.ImageField("封面图",help_text="封面图", upload_to='doc_img')
    title = models.CharField("标题", help_text="标题", max_length=50)
    desc = models.TextField('简介',help_text="简介")
    file_url = models.FileField('文档地址',help_text="文档地址", upload_to='doc_url')

    class Meta:
        db_table = 'doc'
        verbose_name = "文档"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.title
