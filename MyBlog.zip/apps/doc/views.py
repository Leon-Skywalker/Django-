import os.path
from django.conf import settings
from django.http import FileResponse
from django.shortcuts import render
from doc.models import Doc

# Create your views here.
from django.views.generic import ListView


class DocListView(ListView):
    queryset = Doc.objects.filter(is_delete=False)
    paginate_by = 2
    template_name = 'doc/doc.html'


def doc_view(request, file_name):
    response = FileResponse(open(os.path.join(settings.MEDIA_ROOT, 'doc_url', file_name), 'rb'))
    return response