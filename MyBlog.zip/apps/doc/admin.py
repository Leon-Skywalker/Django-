from django.contrib import admin
from doc.models import Doc
# Register your models here.

admin.site.register(Doc)
