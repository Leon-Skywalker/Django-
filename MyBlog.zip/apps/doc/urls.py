from django.urls import path
from doc.views import DocListView, doc_view

app_name = 'doc'

urlpatterns = [
    path('', DocListView.as_view(), name='list'),
    path('doc_view/<str:file_name>', doc_view, name="view"),
]