from django.urls import path
from .views import ArticleDetailView,CommentAddView,CommentChildAddView,ArticleSearchView

app_name = 'article'

urlpatterns = [
    path('<int:pk>',ArticleDetailView.as_view(),name='detail'),
    path('comment/<int:pk>', CommentAddView.as_view(), name='comment_add'),
    path('comment/<int:article_id>/<int:pk>', CommentChildAddView.as_view(), name='comment_child_add'),
    path('search/', ArticleSearchView.as_view(), name='search'),
]
