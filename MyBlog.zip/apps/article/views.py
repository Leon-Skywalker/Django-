from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.urls import reverse
from haystack.generic_views import SearchView,SearchMixin
from django.http import Http404


from article.forms import CommentForm
from article.models import Article, Comment, HotArticle
from django.core.paginator import InvalidPage, Paginator


# Create your views here.
from django.views.generic import DetailView, CreateView, ListView


class ArticleDetailView(DetailView):
    queryset = Article.objects.filter(is_delete=False).select_related('tag','author')
    paginate_by = 3
    paginator_class = Paginator
    template_name = 'article/detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        comment = Comment.objects.filter(is_delete=False,article_id=self.kwargs['pk']).order_by('-create_time')
        comment_count = comment.count()
        context['comment_count'] = comment_count
        paginator, page, comment, _ = self.paginate_queryset(comment, self.paginate_by)
        context['paginator'] = paginator
        context['page_obj'] = page
        context['comments'] = comment
        return context

    def paginate_queryset(self, queryset, page_size):
        """Paginate the queryset, if needed."""
        paginator = self.get_paginator(queryset, page_size)
        page = self.request.GET.get('page', 1)
        try:
            page_number = int(page)
        except ValueError:
            if page == 'last':
                page_number = paginator.num_pages
            else:
                raise Http404(_('Page is not “last”, nor can it be converted to an int.'))
        try:
            page = paginator.page(page_number)
            return (paginator, page, page.object_list, page.has_other_pages())
        except InvalidPage as e:
            raise Http404(_('Invalid page (%(page_number)s): %(message)s') % {
                'page_number': page_number,
                'message': str(e)
            })

    def get_paginator(self, queryset, per_page, orphans=0,
                      allow_empty_first_page=True, **kwargs):
        """Return an instance of the paginator for this view."""
        return self.paginator_class(
            queryset, per_page, orphans=orphans,
            allow_empty_first_page=allow_empty_first_page, **kwargs)


#  文章评论
class CommentAddView(LoginRequiredMixin,CreateView):
    form_class = CommentForm
    model = Comment

    def form_valid(self, form):
        comment = form.save(commit=False)
        comment.article_id = self.kwargs['pk']
        comment.user = self.request.user
        comment.save()
        return super(CommentAddView,self).form_valid(form)

    def get_success_url(self):
        return reverse('article:detail',args=[self.kwargs['pk']])


# 文章子评论
class CommentChildAddView(LoginRequiredMixin,CreateView):
    form_class = CommentForm
    model = Comment

    def form_valid(self, form):
        comment = form.save(commit=False)
        comment.article_id = self.kwargs['article_id']
        comment.user = self.request.user
        comment.parent_id = self.kwargs['pk']
        comment.save()
        return super(CommentChildAddView, self).form_valid(form)

    def get_success_url(self):
        return reverse('article:detail', args=[self.kwargs['article_id']])

# 搜索
class ArticleSearchView(SearchMixin,ListView):
    template_name = 'article/search.html'
    paginate_by = 2
    def get(self, request,*args, **kwargs):
        q = self.request.GET.get('q', '')
        if q:
            form_class = self.get_form_class()
            form = self.get_form(form_class)

            if form.is_valid():
                return self.form_valid(form)
            else:
                return self.form_invalid(form)
        else:
            return super(ArticleSearchView, self).get(request, *args, **kwargs)


    def get_queryset(self):
        q = self.request.GET.get('q', '')
        if q:
            return super(ArticleSearchView, self).get_queryset()
        else:
            # 没有q 就直接去数据库中拿数据
            queryset = HotArticle.objects.filter(is_delete=False).select_related('article', 'article__tag','article__author').order_by('priority')
            return queryset

    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context['q'] = self.request.GET.get('q','')
        return context