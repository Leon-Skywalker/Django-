import datetime
from haystack import indexes
from article.models import Article


class NoteIndex(indexes.SearchIndex, indexes.Indexable):
    # text的内容是由 你想要进行搜索的字段确定的
    text = indexes.CharField(document=True, use_template=True)
    title = indexes.CharField(model_attr='title')
    body = indexes.CharField(model_attr='body')

    def get_model(self):
        return Article

    def index_queryset(self, using=None):
        """Used when the entire index for model is updated."""
        return self.get_model().objects.filter(is_delete=False)