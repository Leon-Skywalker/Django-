from django.db import models
from utills.basemodel import BaseModel
from ckeditor_uploader.fields import RichTextUploadingField
# Create your models here.


# 标签
class Tag(BaseModel):
    name = models.CharField('标签名', help_text='标签名', max_length=25)

    class Meta:
        db_table = 'tag'
        verbose_name = '标签'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


# 文章
class Article(BaseModel):
    img_url = models.ImageField('文章图片地址', help_text='文章图片地址', upload_to='article_img')
    title = models.CharField('标题', help_text='标题', max_length=50)
    body = RichTextUploadingField('正文', help_text='正文')
    summary = models.TextField('文章摘要', help_text='文章摘要')
    tag = models.ForeignKey(Tag, on_delete=models.SET_NULL, null=True)
    author = models.ForeignKey('user.User', on_delete=models.SET_NULL, null=True)

    class Meta:
        db_table = 'article'
        verbose_name = '文章'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.title


# 轮播图
class Banner(BaseModel):
    img_url = models.ImageField('轮播图的地址', help_text='轮播图的地址', upload_to='banner_img')
    priority = models.IntegerField('优先级', help_text='优先级')
    article = models.OneToOneField(Article, on_delete=models.CASCADE)

    class Meta:
        db_table = 'banner'
        verbose_name = '轮播图'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.article.title


# 热门文章
class HotArticle(BaseModel):
    article = models.OneToOneField(Article, help_text='热门文章', on_delete=models.CASCADE)
    priority = models.IntegerField('优先级', help_text='优先级')

    class Meta:
        db_table = 'hot_article'
        verbose_name = '热门文章'
        verbose_name_plural = verbose_name
        indexes=[
            models.Index(fields=['priority'])     # 添加优先级索引
        ]

    def __str__(self):
        return self.article.title


# 评论
class Comment(BaseModel):
    article = models.ForeignKey(Article,on_delete=models.CASCADE)
    user = models.ForeignKey('user.User',on_delete=models.CASCADE)
    body = models.TextField('评论内容',help_text='评论内容')
    parent = models.ForeignKey('self',on_delete=models.CASCADE,null=True)

    class Meta:
        db_table = 'comment'
        verbose_name = '评论'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.article.title
