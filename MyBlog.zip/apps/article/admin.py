from django.contrib import admin
from article.models import Tag, Article, HotArticle, Banner,Comment

# Register your models here.

admin.site.register(Tag)
admin.site.register(Article)
admin.site.register(Banner)
admin.site.register(HotArticle)
admin.site.register(Comment)
