from django.db import models
from utills.basemodel import BaseModel
# Create your models here.


class Teacher(BaseModel):
    name = models.CharField("讲师的名字",help_text="讲师的名字",max_length=15)
    img_url = models.ImageField("头像地址",help_text="头像地址", upload_to='teacher_img')
    title = models.CharField("头衔",help_text="头衔",max_length=15)
    desc = models.TextField("讲师简介",help_text="讲师简介")

    class Meta:
        db_table = 'teacher'
        verbose_name = '讲师'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name


class Course(BaseModel):
    img_url = models.URLField("封面地址",help_text='封面地址')
    video_url = models.URLField("视频地址",help_text='视频地址',max_length=255)
    title = models.CharField("标题",help_text="标题",max_length=50)
    desc = models.TextField("视频简介",help_text="视频简介")
    outline = models.TextField("课程大纲",help_text="课程大纲")
    teacher = models.ForeignKey(Teacher, on_delete=models.SET_NULL, null=True)

    class Meta:
        db_table = 'course'
        verbose_name = '课程'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.title

