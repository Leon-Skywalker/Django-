from django.contrib import admin
from course.models import Course, Teacher

# Register your models here.

admin.site.register(Course)
admin.site.register(Teacher)