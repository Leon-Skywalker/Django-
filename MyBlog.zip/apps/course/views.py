from django.shortcuts import render
from django.views.generic import ListView,DetailView
from course.models import Course
# Create your views here.



class CourseListView(ListView):
    queryset = Course.objects.filter(is_delete=False).select_related('teacher').order_by('-id')
    paginate_by = 2


class CourseDetailView(DetailView):
    queryset = Course.objects.filter(is_delete=False)