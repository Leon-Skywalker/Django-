from django.apps import AppConfig


class BlogIndexConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blogindex'
