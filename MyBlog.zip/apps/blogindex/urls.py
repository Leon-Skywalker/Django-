from django.urls import path
from .views import index,vue_test,vuetify_test,doc,art_detail,course,course_detail,login,register,search

urlpatterns = [
    path('index/',index,name='index'),
    path('vue_test/', vue_test),
    path('vuetify_test/', vuetify_test),
    path('doc/', doc,name='doc'),
    path('art_detail/', art_detail,name='detail'),
    path('course/', course,name='course'),
    path('course_detail/', course_detail, name='course_detail'),
    path('login/', login, name='login'),
    path('register/', register, name='register'),
    path('search/', search, name='search'),
]
