from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
# 首页
def index(request):
    return render(request,'index.html')

def vue_test(request):
    return render(request,'vue.html')

def vuetify_test(request):
    return render(request,'vuetify_test.html')

# 下载文档
def doc(request):
    return render(request,'doc.html')

# 文章详情
def art_detail(request):
    return render(request,'detail.html')

# 课堂页
def course(request):
    return render(request,'course.html')

# 课堂详情页
def course_detail(request):
    return render(request,'course_detail.html')

# 搜索页
def search(request):
    return render(request,'search.html')

# 登录页
def login(request):
    return render(request,'login.html')

# 注册页
def register(request):
    return render(request,'register.html')