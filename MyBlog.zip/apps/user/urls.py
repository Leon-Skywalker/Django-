from django.urls import path
from user.views import LoginView,Logout,Register,verify_mail

app_name = 'user'

urlpatterns = [
    path('login', LoginView.as_view(), name='login'),
    path('logout', Logout, name='logout'),
    path('register', Register.as_view(), name='register'),
    path('verify_email/<str:email>', verify_mail, name='verify_email'),
]