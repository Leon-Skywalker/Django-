from django import forms
from django.contrib.auth.hashers import make_password
from django.core.cache import cache

from user.models import User


class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField()


class UserForm(forms.ModelForm):
    verify_code = forms.CharField()
    repeat_pw = forms.CharField()

    class Meta:
        model = User
        fields = ['username', 'password', 'email']

    def clean_username(self):  # 校验用户名
        username = self.cleaned_data['username']
        user = User.objects.filter(username=username).first()
        if user:
            raise forms.ValidationError('用户名存在！')
        return username

    def clean_password(self):  # 校验密码与确认密码
        password = self.cleaned_data['password']
        # repeat_pw = self.cleaned_data['repeat_pw']
        if self.data['repeat_pw'] != password:
            raise forms.ValidationError('用户名或密码错误！')
        return make_password(password)

    def clean_email(self):  # 校验邮箱
        email = self.cleaned_data['email']
        email_data = User.objects.filter(email=email).first()
        if email_data:
            raise forms.ValidationError('邮箱已注册！')
        verify_code = self.data['verify_code']
        email_code = cache.get('email_code:{}'.format(email))  # 从redis取验证码
        if verify_code != str(email_code):
            raise forms.ValidationError('验证码错误！')
        return email