import random

from django.conf import settings
from django.core.cache import cache
from django.core.mail import send_mail
from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render
from django.urls import reverse
from django.views.generic import FormView, CreateView
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.models import Permission

from user.forms import LoginForm, UserForm


# Create your views here.
class LoginView(FormView):
    template_name = 'user/login.html'
    form_class = LoginForm

    def form_valid(self, form):
        user = authenticate(self.request, username=form.cleaned_data['username'],
                            password=form.cleaned_data['password'])
        login(self.request, user)
        return super(LoginView, self).form_valid(form)

    def get_success_url(self):
        return reverse('home')


def Logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('user:login'))


class Register(CreateView):
    template_name = 'user/register.html'
    form_class = UserForm

    def form_valid(self, form):
        user = form.save()
        user.is_staff = True
        permissions = Permission.objects.filter(codename__in=[
            'add_article', 'change_article', 'view_article', 'delete_article',
            'add_course', 'change_course', 'view_course', 'delete_course',
            'add_doc', 'change_doc', 'view_doc',
        ])
        user.user_permissions.set(permissions)
        user.save()
        return super(Register, self).form_valid(form)

    def get_success_url(self):
        return reverse('user:login')


def verify_mail(request, email):
    email_code = random.randint(1000, 9999)
    cache.set('email_code:{}'.format(email), email_code, timeout=120)
    print(email_code)
    send_mail(
        '已发送',
        '你的验证码是{}，2分钟内有效'.format(email_code),
        settings.EMAIL_HOST_USER,
        [email],
        fail_silently=False,
    )
    return HttpResponse('ok')
